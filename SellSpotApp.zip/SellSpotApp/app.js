const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const multer = require('multer');

const app = express();

// App setup
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: false }));

// Session and flash messages
app.use(
  session({
    secret: 'sellspot-secret',
    resave: false,
    saveUninitialized: false
  })
);
app.use(flash());

app.use((req, res, next) => {
  res.locals.currentUser = req.session.user || null;
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  next();
});

// Temporary local data.
// These arrays will be replaced with MySQL queries when the team database is ready.
let users = [];
let listings = [];
let nextUserId = 1;
let nextListingId = 1;

// Multer setup for listing image upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/images');
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '-' + file.originalname;
    cb(null, uniqueName);
  }
});

const upload = multer({ storage: storage });

// Check whether a user is logged in
function checkAuthenticated(req, res, next) {
  if (req.session.user) {
    return next();
  }

  req.flash('error', 'Please log in first.');
  res.redirect('/login');
}

// Admins can manage all listings. Users can manage only their own listings.
function canManageListing(user, listing) {
  return user.role === 'admin' || user.id === listing.sellerId;
}

// Display all listings with simple search and category filtering
app.get('/', (req, res) => {
  const search = req.query.search || '';
  const category = req.query.category || '';
  let results = listings;

  if (search) {
    results = results.filter((listing) =>
      listing.title.toLowerCase().includes(search.toLowerCase())
    );
  }

  if (category) {
    results = results.filter((listing) => listing.category === category);
  }

  res.render('index', {
    listings: results,
    search: search,
    category: category
  });
});

// Display one listing
app.get('/listing/:id', (req, res) => {
  const listingId = parseInt(req.params.id);
  const listing = listings.find((item) => item.id === listingId);

  if (listing) {
    res.render('listing', { listing: listing });
  } else {
    res.send('Listing not found');
  }
});

// Display registration form
app.get('/register', (req, res) => {
  res.render('register');
});

// Create a local account
app.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;
  const existingUser = users.find((user) => user.email === email);

  if (existingUser) {
    req.flash('error', 'This email or login name is already used.');
    return res.redirect('/register');
  }

  const newUser = {
    id: nextUserId,
    name: name,
    email: email,
    password: password,
    role: role === 'admin' ? 'admin' : 'user'
  };

  users.push(newUser);
  nextUserId++;

  req.session.user = {
    id: newUser.id,
    name: newUser.name,
    email: newUser.email,
    role: newUser.role
  };

  req.flash('success', 'Account created successfully.');
  res.redirect('/');
});

// Display login form
app.get('/login', (req, res) => {
  res.render('login');
});

// Log in using temporary local account data
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find((item) => item.email === email && item.password === password);

  if (!user) {
    req.flash('error', 'Email/login or password is incorrect.');
    return res.redirect('/login');
  }

  req.session.user = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role
  };

  req.flash('success', 'Login successful.');
  res.redirect('/');
});

// Log out
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// Display add listing form
app.get('/addListing', checkAuthenticated, (req, res) => {
  res.render('addListing');
});

// Add new listing to temporary local data
app.post('/addListing', checkAuthenticated, upload.single('image'), (req, res) => {
  const { title, description, price, category, condition, location } = req.body;
  const image = req.file ? req.file.filename : '';

  const newListing = {
    id: nextListingId,
    title: title,
    description: description,
    price: price,
    category: category,
    condition: condition,
    location: location,
    image: image,
    sellerId: req.session.user.id,
    sellerName: req.session.user.name
  };

  listings.push(newListing);
  nextListingId++;

  req.flash('success', 'Listing added successfully.');
  res.redirect('/');
});

// Display listings managed by the current user
app.get('/myListings', checkAuthenticated, (req, res) => {
  let results;

  if (req.session.user.role === 'admin') {
    results = listings;
  } else {
    results = listings.filter((listing) => listing.sellerId === req.session.user.id);
  }

  res.render('myListings', { listings: results });
});

// Display edit listing form
app.get('/editListing/:id', checkAuthenticated, (req, res) => {
  const listingId = parseInt(req.params.id);
  const listing = listings.find((item) => item.id === listingId);

  if (!listing) {
    return res.send('Listing not found');
  }

  if (!canManageListing(req.session.user, listing)) {
    req.flash('error', 'You cannot edit this listing.');
    return res.redirect('/');
  }

  res.render('editListing', { listing: listing });
});

// Update listing in temporary local data
app.post('/editListing/:id', checkAuthenticated, upload.single('image'), (req, res) => {
  const listingId = parseInt(req.params.id);
  const listing = listings.find((item) => item.id === listingId);

  if (!listing) {
    return res.send('Listing not found');
  }

  if (!canManageListing(req.session.user, listing)) {
    req.flash('error', 'You cannot edit this listing.');
    return res.redirect('/');
  }

  const { title, description, price, category, condition, location } = req.body;

  listing.title = title;
  listing.description = description;
  listing.price = price;
  listing.category = category;
  listing.condition = condition;
  listing.location = location;

  if (req.file) {
    listing.image = req.file.filename;
  }

  req.flash('success', 'Listing updated successfully.');
  res.redirect('/listing/' + listing.id);
});

// Delete listing from temporary local data
app.get('/deleteListing/:id', checkAuthenticated, (req, res) => {
  const listingId = parseInt(req.params.id);
  const listing = listings.find((item) => item.id === listingId);

  if (!listing) {
    return res.send('Listing not found');
  }

  if (!canManageListing(req.session.user, listing)) {
    req.flash('error', 'You cannot delete this listing.');
    return res.redirect('/');
  }

  listings = listings.filter((item) => item.id !== listingId);
  req.flash('success', 'Listing deleted successfully.');
  res.redirect('/myListings');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`SellSpot started on http://localhost:${PORT}`);
});

